package com.example.classroomregister

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.classroomregister.data.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

private val statuses = listOf("PRESENT","ABSENT","SICK","AUTHORIZED_LEAVE")
private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

class MainActivity: ComponentActivity(){
    override fun onCreate(savedInstanceState: Bundle?){ super.onCreate(savedInstanceState); setContent{ MaterialTheme{ RegisterApp() } } }
}

class RegisterVm(private val db: AppDatabase): ViewModel(){
    val years=db.years().all(); val classes=db.classes().all()
    var selectedClassId by mutableStateOf<Long?>(null); var selectedDate by mutableStateOf(today()); var message by mutableStateOf<String?>(null)
    fun learners(classId:Long,date:String)=db.learners().eligible(classId,date)
    fun allLearners(classId:Long)=db.learners().byClass(classId)
    suspend fun initialize(){
        val existingYears=db.years().all().first()
        if(existingYears.isEmpty()){ val current=Calendar.getInstance().get(Calendar.YEAR); val id=db.years().insert(AcademicYear(year=current)); for(i in 1..3) db.terms().insert(Term(name="Term $i",academicYearId=id)); }
        if(selectedClassId==null) selectedClassId=db.classes().all().first().firstOrNull()?.id
    }
    suspend fun saveAttendance(date:String, values:Map<Long,String>){
        val c=db.classes().get(selectedClassId?:return)?:return; val term=db.terms().get(c.termId)?:return
        val eligible=db.learners().eligible(c.id,date).first()
        for(l in eligible){ val s=values[l.id]?:"PRESENT"; val old=db.attendance().forDate(c.id,date).firstOrNull{it.learnerId==l.id}; db.attendance().upsert(Attendance(old?.id?:0,l.id,c.id,date,s,c.academicYearId,term.id,createdAt=old?.createdAt?:System.currentTimeMillis())) }
        message="Attendance saved for $date"
    }
    suspend fun addLearner(l:Learner):Boolean{ if(db.learners().duplicateCode(l.classId,l.codeNumber)>0){message="Code number already exists in this class";return false}; db.learners().insert(l);message="Learner saved";return true }
    suspend fun transfer(l:Learner,date:String,destination:String,reason:String){db.learners().update(l.copy(status="TRANSFERRED",transferDate=date,transferDestination=destination,transferReason=reason,updatedAt=System.currentTimeMillis()));message="Learner marked as transferred"}
}
private class VmFactory(private val db:AppDatabase):ViewModelProvider.Factory{override fun <T:ViewModel> create(c:Class<T>):T=RegisterVm(db) as T}

@Composable fun RegisterApp(){
    val ctx=LocalContext.current; val db=remember{AppDatabase.get(ctx)}; val vm:RegisterVm=viewModel(factory=VmFactory(db)); val nav=rememberNavController(); val scope=rememberCoroutineScope()
    LaunchedEffect(Unit){scope.launch{vm.initialize()}}
    vm.message?.let{msg->LaunchedEffect(msg){ kotlinx.coroutines.delay(1800);vm.message=null }}
    Scaffold(bottomBar={NavigationBar{listOf("Home" to "home","Learners" to "learners","Attendance" to "attendance","Reports" to "reports","Settings" to "settings").forEach{(label,route)->NavigationBarItem(selected=false,onClick={nav.navigate(route){launchSingleTop=true}},icon={Text(label.first().toString())},label={Text(label)})}}}){p->
        NavHost(navController=nav,startDestination="home",modifier=Modifier.padding(p)){
            composable("home"){Home(vm,nav)}; composable("learners"){Learners(vm,nav)}; composable("add"){AddLearner(vm,nav)}; composable("attendance"){AttendanceScreen(vm)}; composable("reports"){Reports(vm,ctx)}; composable("settings"){Settings(vm)}
        }
    }
}

@Composable private fun Home(vm:RegisterVm,nav:NavHostController){ val cs by vm.classes.collectAsState(emptyList()); val c=cs.firstOrNull{it.id==vm.selectedClassId}?:cs.firstOrNull(); LaunchedEffect(c){if(vm.selectedClassId==null)vm.selectedClassId=c?.id}; val learners=if(c==null) emptyList() else vm.allLearners(c.id).collectAsState(emptyList()).value
    Column(Modifier.fillMaxSize().padding(20.dp)){Text("GOOD MORNING",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("My classroom. My records. My control.");Spacer(Modifier.height(24.dp));Text("Academic year: ${c?.academicYearId?:"—"}");Text("Class: ${c?.name?:"Create a class in Settings"}");Text("Active learners: ${learners.count{it.status=="ACTIVE"}}");Spacer(Modifier.height(20.dp));Button(onClick={nav.navigate("attendance")},Modifier.fillMaxWidth()){Text("MARK TODAY'S ATTENDANCE")};Spacer(Modifier.height(10.dp));OutlinedButton(onClick={nav.navigate("learners")},Modifier.fillMaxWidth()){Text("VIEW LEARNERS")};Spacer(Modifier.height(10.dp));OutlinedButton(onClick={nav.navigate("reports")},Modifier.fillMaxWidth()){Text("VIEW REPORTS")}}
}

@Composable private fun Learners(vm:RegisterVm,nav:NavHostController){val c=vm.selectedClassId;var q by remember{mutableStateOf("")};val list=if(c==null) emptyList() else if(q.isBlank()) vm.allLearners(c).collectAsState(emptyList()).value else vm.allLearners(c).collectAsState(emptyList()).value.filter{it.fullName.contains(q,true)||it.codeNumber.contains(q,true)};Column(Modifier.fillMaxSize().padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Learners",style=MaterialTheme.typography.headlineSmall);Button(onClick={nav.navigate("add")}){Text("Add")}};Spacer(Modifier.height(8.dp));TextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Search name or code")});Spacer(Modifier.height(8.dp));LazyColumn{items(list,key={it.id}){l->Card(Modifier.fillMaxWidth().padding(vertical=3.dp)){ListItem(headlineContent={Text(l.fullName)},supportingContent={Text("${l.sex} • Age ${l.age?:"—"} • ${l.codeNumber} • ${l.status}")})}}}}}

@Composable private fun AddLearner(vm:RegisterVm,nav:NavHostController){val scope=rememberCoroutineScope();val classId=vm.selectedClassId;var name by remember{mutableStateOf("")};var sex by remember{mutableStateOf("Male")};var age by remember{mutableStateOf("")};var dob by remember{mutableStateOf("")};var code by remember{mutableStateOf("")};var join by remember{mutableStateOf(today())};var guardian by remember{mutableStateOf("")};var rel by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var alt by remember{mutableStateOf("")};var emergency by remember{mutableStateOf("")};var village by remember{mutableStateOf("")};var district by remember{mutableStateOf("")};var church by remember{mutableStateOf("")};var disability by remember{mutableStateOf("")};var notes by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(16.dp)){Text("ADD LEARNER",style=MaterialTheme.typography.headlineSmall);Field("Full Name *",name){name=it};Field("Sex",sex){sex=it};Field("Age",age){age=it};Field("Date of Birth (yyyy-MM-dd)",dob){dob=it};Field("Code Number *",code){code=it};Field("Date Joined (yyyy-MM-dd) *",join){join=it};Field("Parent / Guardian",guardian){guardian=it};Field("Relationship",rel){rel=it};Field("Phone Number",phone){phone=it};Field("Alternative Phone",alt){alt=it};Field("Emergency Contact",emergency){emergency=it};Field("Village / Home Location",village){village=it};Field("Home District",district){district=it};Field("Church",church){church=it};Field("Disability / Special Needs",disability){disability=it};Field("Other Notes",notes){notes=it};Spacer(Modifier.height(8.dp));Button(enabled=classId!=null,onClick={scope.launch{if(name.isBlank()||code.isBlank()||join.isBlank()){vm.message="Name, code and joining date are required"}else{val ok=vm.addLearner(Learner(fullName=name.trim(),sex=sex,age=age.toIntOrNull(),dateOfBirth=dob.ifBlank{null},codeNumber=code.trim(),classId=classId!!,joinDate=join,guardianName=guardian,guardianRelationship=rel,guardianPhone=phone,alternativePhone=alt,emergencyContact=emergency,village=village,homeDistrict=district,church=church,disability=disability,notes=notes));if(ok)nav.popBackStack()}}},Modifier.fillMaxWidth()){Text("SAVE LEARNER")}}}
@Composable private fun Field(label:String,value:String,onChange:(String)->Unit){TextField(value,onChange,Modifier.fillMaxWidth().padding(vertical=2.dp),label={Text(label)},singleLine=true)}

@Composable private fun AttendanceScreen(vm:RegisterVm){val ctx=LocalContext.current;val classId=vm.selectedClassId;if(classId==null){Column(Modifier.padding(20.dp)){Text("Create/select a class first.")};return};val learners=vm.learners(classId,vm.selectedDate).collectAsState(emptyList()).value;val scope=rememberCoroutineScope();var values by remember(vm.selectedDate,classId){mutableStateOf<Map<Long,String>>(emptyMap())};LaunchedEffect(classId,vm.selectedDate){val old=vm.classes;val db=AppDatabase.get(ctx);val existing=db.attendance().forDate(classId,vm.selectedDate);values=existing.associate{it.learnerId to it.status}};Column(Modifier.fillMaxSize().padding(16.dp)){Text("ATTENDANCE",style=MaterialTheme.typography.headlineSmall);Field("Date (yyyy-MM-dd)",vm.selectedDate){vm.selectedDate=it};Text("${learners.size} eligible learners",Modifier.padding(vertical=6.dp));Row{Button(onClick={values=learners.associate{it.id to "PRESENT"}}){Text("MARK ALL PRESENT")};Spacer(Modifier.width(8.dp));Button(onClick={scope.launch{vm.saveAttendance(vm.selectedDate,values)}}){Text("SAVE")}};LazyColumn{items(learners,key={it.id}){l->val s=values[l.id]?:"PRESENT";Card(Modifier.fillMaxWidth().padding(vertical=3.dp)){ListItem(headlineContent={Text(l.fullName)},supportingContent={Text("${l.codeNumber} • $s")},trailingContent={Row{statuses.forEach{st->FilterChip(selected=s==st,onClick={values=values+(l.id to st)},label={Text(st.take(1))})}}})}}}}}

@Composable private fun Reports(vm:RegisterVm,ctx:Context){val classId=vm.selectedClassId;val scope=rememberCoroutineScope();var from by remember{mutableStateOf("2026-01-01")};var to by remember{mutableStateOf(today())};var busy by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().padding(16.dp)){Text("REPORTS",style=MaterialTheme.typography.headlineSmall);Text("Physical-register style PDF from stored records.");Field("From date",from){from=it};Field("To date",to){to=it};Spacer(Modifier.height(10.dp));Button(enabled=classId!=null&&!busy,onClick={busy=true;scope.launch(Dispatchers.IO){val file=buildRegisterPdf(ctx,AppDatabase.get(ctx),classId!!,from,to);withContext(Dispatchers.Main){busy=false;shareFile(ctx,file)}}}){Text(if(busy)"GENERATING…" else "GENERATE PDF")}}}

private suspend fun buildRegisterPdf(ctx:Context,db:AppDatabase,classId:Long,from:String,to:String):File{val c=db.classes().get(classId)?:error("Class not found");val learners=db.learners().byClass(classId).first();val doc=PdfDocument();var pageNo=1;var page=doc.startPage(PdfDocument.PageInfo.Builder(842,595,pageNo).create());var canvas=page.canvas;val p=Paint().apply{color=Color.BLACK;textSize=9f};canvas.drawText("CLASSROOM ATTENDANCE REGISTER",24f,28f,p);canvas.drawText("Class: ${c.name}    Period: $from to $to",24f,44f,p);var y=70f;val start=java.time.LocalDate.parse(from);val end=java.time.LocalDate.parse(to);val dates=generateSequence(start){it.plusDays(1)}.takeWhile{!it.isAfter(end)}.toList();val week=dates.chunked(5);for((wi,days) in week.withIndex()){if(y>520){doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(842,595,pageNo).create());canvas=page.canvas;y=35f}canvas.drawText("WEEK ${wi+1}  ${days.first()}",24f,y,p);y+=14;canvas.drawText("No  Learner Name                         Sex Age Code   "+days.joinToString(" "){it.dayOfMonth.toString()},",24f,y,p);y+=12;for((i,l) in learners.withIndex()){var line=String.format(Locale.US,"%-3d %-38s %-3s %-3s %-6s",i+1,l.fullName.take(38),l.sex.take(1),l.age?:"-",l.codeNumber.take(6));for(d in days){val a=db.attendance().forDate(classId,d.toString()).firstOrNull{it.learnerId==l.id};line+=" "+(code(a?.status));};canvas.drawText(line,24f,y,p);y+=12;if(y>540){doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(842,595,pageNo).create());canvas=page.canvas;y=35f}}y+=12};doc.finishPage(page);val file=File(ctx.cacheDir,"classroom_register_${from}_$to.pdf");file.outputStream().use{doc.writeTo(it)};doc.close();return file}
private fun code(s:String?)=when(s){"PRESENT"->"P";"ABSENT"->"A";"SICK"->"S";"AUTHORIZED_LEAVE"->"L";else->"—"}
private fun shareFile(ctx:Context,file:File){val uri:Uri=FileProvider.getUriForFile(ctx,ctx.packageName+".provider",file);ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share / Print register"))}

@Composable private fun Settings(vm:RegisterVm){val ctx=LocalContext.current;val scope=rememberCoroutineScope();var year by remember{mutableStateOf("")};var className by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(16.dp)){Text("SETTINGS",style=MaterialTheme.typography.headlineSmall);Text("Create academic years and classes. School and teacher details can be configured without automatic sharing.");Field("New academic year",year){year=it};Button(onClick={scope.launch{val y=year.toIntOrNull();if(y==null){vm.message="Enter a valid year"}else{val db=AppDatabase.get(ctx);val id=db.years().insert(AcademicYear(year=y));if(id>0){for(i in 1..3)db.terms().insert(Term(name="Term $i",academicYearId=id));year="";vm.message="Academic year created"}else vm.message="That academic year already exists"}}}){Text("ADD YEAR")};Spacer(Modifier.height(12.dp));Field("New class / Standard",className){className=it};Button(onClick={scope.launch{if(className.isBlank()){vm.message="Enter a class name"}else{val db=AppDatabase.get(ctx);val y=db.years().all().first().firstOrNull();if(y==null){vm.message="Create an academic year first"}else{val t=db.terms().byYear(y.id).first().firstOrNull();if(t==null)vm.message="No term found" else{db.classes().insert(SchoolClass(name=className.trim(),academicYearId=y.id,termId=t.id));className="";vm.message="Class created"}}}}}){Text("ADD CLASS")};Spacer(Modifier.height(16.dp));Text("Attendance statuses: Present, Absent, Sick, Authorized Leave");Text("Core records remain on this device unless you explicitly share a PDF or export.")}}
