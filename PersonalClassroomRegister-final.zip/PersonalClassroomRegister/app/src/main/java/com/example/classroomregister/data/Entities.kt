package com.example.classroomregister.data

import androidx.room.*

@Entity(tableName="academic_years",indices=[Index(value=["year"],unique=true)])
data class AcademicYear(@PrimaryKey(autoGenerate=true) val id:Long=0,val year:Int)
@Entity(tableName="terms",foreignKeys=[ForeignKey(entity=AcademicYear::class,parentColumns=["id"],childColumns=["academicYearId"],onDelete=ForeignKey.CASCADE)],indices=[Index("academicYearId")])
data class Term(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val academicYearId:Long,val startDate:String?=null,val endDate:String?=null)
@Entity(tableName="classes",foreignKeys=[ForeignKey(entity=AcademicYear::class,parentColumns=["id"],childColumns=["academicYearId"],onDelete=ForeignKey.CASCADE),ForeignKey(entity=Term::class,parentColumns=["id"],childColumns=["termId"],onDelete=ForeignKey.CASCADE)],indices=[Index("academicYearId"),Index("termId")])
data class SchoolClass(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val academicYearId:Long,val termId:Long,val teacherName:String="",val schoolName:String="",val description:String="")
@Entity(tableName="learners",foreignKeys=[ForeignKey(entity=SchoolClass::class,parentColumns=["id"],childColumns=["classId"],onDelete=ForeignKey.RESTRICT)],indices=[Index("classId"),Index(value=["classId","codeNumber"],unique=true)])
data class Learner(@PrimaryKey(autoGenerate=true) val id:Long=0,val fullName:String,val sex:String,val age:Int?,val dateOfBirth:String?,val codeNumber:String,val classId:Long,val joinDate:String,val guardianName:String="",val guardianRelationship:String="",val guardianPhone:String="",val alternativePhone:String="",val emergencyContact:String="",val village:String="",val homeDistrict:String="",val church:String="",val disability:String="",val notes:String="",val status:String="ACTIVE",val transferDate:String?=null,val transferDestination:String="",val transferReason:String="",val transferRemarks:String="",val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=System.currentTimeMillis())
@Entity(tableName="attendance",foreignKeys=[ForeignKey(entity=Learner::class,parentColumns=["id"],childColumns=["learnerId"],onDelete=ForeignKey.RESTRICT),ForeignKey(entity=SchoolClass::class,parentColumns=["id"],childColumns=["classId"],onDelete=ForeignKey.RESTRICT)],indices=[Index("learnerId"),Index("classId"),Index(value=["learnerId","date","classId"],unique=true)])
data class Attendance(@PrimaryKey(autoGenerate=true) val id:Long=0,val learnerId:Long,val classId:Long,val date:String,val status:String,val academicYearId:Long,val termId:Long,val notes:String="",val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=System.currentTimeMillis())
@Entity(tableName="settings") data class AppSetting(@PrimaryKey val key:String,val value:String)
