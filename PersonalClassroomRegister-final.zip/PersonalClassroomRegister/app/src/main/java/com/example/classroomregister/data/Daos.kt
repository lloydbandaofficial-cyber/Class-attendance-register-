package com.example.classroomregister.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface AcademicYearDao {
    @Query("SELECT * FROM academic_years ORDER BY year DESC") fun all(): Flow<List<AcademicYear>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(x: AcademicYear): Long
    @Query("SELECT * FROM academic_years WHERE id=:id") suspend fun get(id: Long): AcademicYear?
}
@Dao interface TermDao {
    @Query("SELECT * FROM terms WHERE academicYearId=:yearId ORDER BY id") fun byYear(yearId: Long): Flow<List<Term>>
    @Insert suspend fun insert(x: Term): Long
    @Query("SELECT * FROM terms WHERE id=:id") suspend fun get(id: Long): Term?
}
@Dao interface ClassDao {
    @Query("SELECT * FROM classes ORDER BY academicYearId DESC, name") fun all(): Flow<List<SchoolClass>>
    @Query("SELECT * FROM classes WHERE id=:id") suspend fun get(id: Long): SchoolClass?
    @Insert suspend fun insert(x: SchoolClass): Long
    @Update suspend fun update(x: SchoolClass)
}
@Dao interface LearnerDao {
    @Query("SELECT * FROM learners WHERE classId=:classId ORDER BY fullName") fun byClass(classId: Long): Flow<List<Learner>>
    @Query("SELECT * FROM learners WHERE classId=:classId AND status='ACTIVE' AND joinDate<=:date AND (transferDate IS NULL OR transferDate>=:date) ORDER BY fullName") fun eligible(classId: Long, date: String): Flow<List<Learner>>
    @Query("SELECT * FROM learners WHERE classId=:classId AND (fullName LIKE '%'||:q||'%' OR codeNumber LIKE '%'||:q||'%') ORDER BY fullName") fun search(classId: Long, q: String): Flow<List<Learner>>
    @Query("SELECT * FROM learners WHERE id=:id") fun observe(id: Long): Flow<Learner?>
    @Insert suspend fun insert(x: Learner): Long
    @Update suspend fun update(x: Learner)
    @Query("SELECT COUNT(*) FROM learners WHERE classId=:classId AND codeNumber=:code AND id!=:id") suspend fun duplicateCode(classId: Long, code: String, id: Long = 0): Int
}
@Dao interface AttendanceDao {
    @Query("SELECT * FROM attendance WHERE classId=:classId AND date=:date ORDER BY learnerId") suspend fun forDate(classId: Long, date: String): List<Attendance>
    @Query("SELECT * FROM attendance WHERE learnerId=:learnerId ORDER BY date") fun history(learnerId: Long): Flow<List<Attendance>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(x: Attendance)
    @Query("DELETE FROM attendance WHERE learnerId=:learnerId AND date=:date AND classId=:classId") suspend fun delete(learnerId: Long, date: String, classId: Long)
    @Query("SELECT status, COUNT(*) count FROM attendance WHERE learnerId=:learnerId GROUP BY status") suspend fun learnerCounts(learnerId: Long): List<StatusCount>
    @Query("SELECT status, COUNT(*) count FROM attendance WHERE classId=:classId AND date BETWEEN :from AND :to GROUP BY status") suspend fun classCounts(classId: Long, from: String, to: String): List<StatusCount>
}
data class StatusCount(val status: String, val count: Int)
@Dao interface SettingDao {
    @Query("SELECT * FROM settings WHERE `key`=:key") suspend fun get(key: String): AppSetting?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(x: AppSetting)
}
