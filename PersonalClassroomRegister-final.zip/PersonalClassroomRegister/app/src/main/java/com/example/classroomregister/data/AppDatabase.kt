package com.example.classroomregister.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities=[AcademicYear::class,Term::class,SchoolClass::class,Learner::class,Attendance::class,AppSetting::class],version=1,exportSchema=false)
abstract class AppDatabase: RoomDatabase(){
    abstract fun years(): AcademicYearDao
    abstract fun terms(): TermDao
    abstract fun classes(): ClassDao
    abstract fun learners(): LearnerDao
    abstract fun attendance(): AttendanceDao
    abstract fun settings(): SettingDao
    companion object { @Volatile private var INSTANCE: AppDatabase?=null
        fun get(ctx:Context):AppDatabase=INSTANCE?:synchronized(this){INSTANCE?:Room.databaseBuilder(ctx.applicationContext,AppDatabase::class.java,"classroom_register.db").build().also{INSTANCE=it}}
    }
}
