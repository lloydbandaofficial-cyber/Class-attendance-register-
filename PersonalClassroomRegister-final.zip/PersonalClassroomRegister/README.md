# Personal Classroom Register

A private, offline-first Android classroom attendance register for an individual teacher.

## Scope
- Local Room database; no automatic school/admin sharing.
- Academic years, terms and teacher-created classes.
- Detailed learner profiles, joining dates and preserved transfer history.
- Date-based attendance with Present, Absent, Sick and Authorized Leave.
- Attendance history and configurable data model for statistics.
- Physical-register-style PDF generation from stored attendance data.
- Explicit PDF sharing/printing through Android's share sheet.

## Build
Open the repository in Android Studio or run Gradle 8.9 with JDK 17:

```bash
gradle assembleDebug
```

GitHub Actions builds a debug APK on pushes and pull requests to `main`/`master`.

## Privacy
The app is designed around: **My classroom. My records. My database. My control.**
No analytics SDK or automatic cloud synchronization is included.

## Source of requirements
The implementation follows `Personal_Classroom_Register_Project_Specification.pdf` supplied with the project.
