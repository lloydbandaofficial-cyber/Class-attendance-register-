# Publishing this project with GitHub

## 1. Create the repository
Create an empty GitHub repository named `PersonalClassroomRegister`.

## 2. Push this project
From the project root:

```bash
git init
git add .
git commit -m "Initial Personal Classroom Register release"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/PersonalClassroomRegister.git
git push -u origin main
```

## 3. Build verification
GitHub Actions runs the Android build automatically on pushes and pull requests. The workflow is in `.github/workflows/android.yml` and uploads the debug APK as a workflow artifact.

## 4. GitHub Release
After the CI build succeeds, download the generated APK artifact, create a GitHub Release, and attach the APK. For a production signed APK/AAB, configure a GitHub Actions signing keystore using GitHub Secrets; never commit the keystore or passwords to the repository.

## 5. Before public distribution
Replace the default application icon, review the package/application ID, add a production privacy policy if required by the distribution channel, and perform a real-device acceptance test of database migration, attendance, transfer history, PDF generation, and sharing/printing.
